// RevM2 - background service worker (MV3)
import {
  getSession,
  setSession,
  clearSession,
  apiRequest,
  getSettings,
  setSettings,
} from "./utils/storage.js";

// Dynamic rule ID ranges - kept clear of each other and of any static rules
// (adult_blocklist / adult_keyword_domains live in separate static rulesets
// and don't use dynamic IDs at all).
const BLACKLIST_RULE_ID_BASE = 20000; // one redirect rule per blocked domain (20000-20999)
const WHITELIST_CATCHALL_ID = 21000; // single rule: redirect every main_frame nav by default
const WHITELIST_ALLOW_ID_BASE = 21001; // one allow rule per whitelisted domain (21001-21999)
const DYNAMIC_RULE_RANGE_START = BLACKLIST_RULE_ID_BASE;
const DYNAMIC_RULE_RANGE_END = WHITELIST_ALLOW_ID_BASE + 999; // 21999

const SYNC_ALARM = "revm2-sync";
const END_ALARM = "revm2-session-end";

// ---------- Blocking rules ----------

// Domains that stay reachable even in whitelist mode, regardless of what the
// person typed - so a strict "allow only these sites" block can never lock
// them out of the RevM2 site itself (needed to end the session, pay for an
// emergency unlock, etc.) or basic local dev testing.
function alwaysAllowedDomains(settings) {
  const out = new Set(["revm2.app", "localhost", "127.0.0.1"]);
  const fromUrl = (u) => {
    try {
      out.add(new URL(u).hostname.replace(/^www\./, ""));
    } catch {}
  };
  if (settings?.webBase) fromUrl(settings.webBase);
  if (settings?.apiBase) fromUrl(settings.apiBase);
  return Array.from(out);
}

async function applyBlockRules(sites, mode = "blacklist") {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds = existing
    .filter((r) => r.id >= DYNAMIC_RULE_RANGE_START && r.id <= DYNAMIC_RULE_RANGE_END)
    .map((r) => r.id);

  let addRules;

  if (mode === "whitelist") {
    const settings = await getSettings();
    const allowDomains = Array.from(new Set([...sites, ...alwaysAllowedDomains(settings)])).slice(
      0,
      999
    );

    // Catch-all: redirect every top-level navigation by default. Uses a
    // regex capture so the blocked page can still show which site got
    // caught, even though this is a single static rule covering everything.
    const catchAll = {
      id: WHITELIST_CATCHALL_ID,
      priority: 1,
      action: {
        type: "redirect",
        redirect: {
          regexSubstitution: `${chrome.runtime.getURL("blocked/blocked.html")}?site=\\1&mode=whitelist`,
        },
      },
      condition: {
        regexFilter: "^https?://([^/:?#]+)",
        resourceTypes: ["main_frame"],
      },
    };

    // Per-domain allow rules, given higher priority so they win over the
    // catch-all above for anything on the allow list (requestDomains also
    // matches subdomains automatically).
    const allowRules = allowDomains.map((domain, i) => ({
      id: WHITELIST_ALLOW_ID_BASE + i,
      priority: 2,
      action: { type: "allow" },
      condition: {
        requestDomains: [domain],
        resourceTypes: ["main_frame"],
      },
    }));

    addRules = [catchAll, ...allowRules];
  } else {
    addRules = sites.map((domain, i) => ({
      id: BLACKLIST_RULE_ID_BASE + i,
      priority: 1,
      action: {
        type: "redirect",
        redirect: {
          extensionPath: `/blocked/blocked.html?site=${encodeURIComponent(domain)}&mode=blacklist`,
        },
      },
      condition: {
        requestDomains: [domain],
        resourceTypes: ["main_frame"],
      },
    }));
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules,
  });
}

async function clearBlockRules() {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds = existing
    .filter((r) => r.id >= DYNAMIC_RULE_RANGE_START && r.id <= DYNAMIC_RULE_RANGE_END)
    .map((r) => r.id);
  if (removeIds.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: removeIds });
  }
}

// ---------- Session lifecycle ----------

async function startSession({ blockName, sites, durationMinutes, mode }) {
  const startedAt = new Date().toISOString();
  const unlimited = !durationMinutes;
  const endsAt = unlimited
    ? null
    : new Date(Date.now() + durationMinutes * 60_000).toISOString();

  // "blacklist" (default) = block just these sites, everything else stays
  // reachable. "whitelist" = only these sites stay reachable, everything
  // else gets redirected to the blocked page. Anything unrecognized falls
  // back to blacklist, so older sessions synced from the website (which may
  // not send `mode` yet) keep working exactly as before.
  const resolvedMode = mode === "whitelist" ? "whitelist" : "blacklist";

  const session = {
    active: true,
    blockName,
    sites,
    mode: resolvedMode,
    startedAt,
    endsAt,
    unlimited,
    verified: true, // downgraded to false if the person uses the manual code or emergency unlock
    usedEmergencyUnlock: false,
  };

  await setSession(session);
  await applyBlockRules(sites, resolvedMode);

  if (endsAt) {
    await chrome.alarms.create(END_ALARM, { when: new Date(endsAt).getTime() });
  } else {
    await chrome.alarms.clear(END_ALARM);
  }

  // Best-effort sync so the website / Live Grid can show the session
  // (and, later, the verified badge) as soon as it starts.
  apiRequest("/api/extension/session/start", {
    method: "POST",
    body: JSON.stringify(session),
  });

  updateBadge(session);
  return session;
}

async function endSession(reason) {
  const session = await getSession();
  if (!session) return;

  await clearBlockRules();
  await chrome.alarms.clear(END_ALARM);

  const verified = session.verified && reason === "completed";

  apiRequest("/api/extension/session/end", {
    method: "POST",
    body: JSON.stringify({ reason, verified }),
  });

  await clearSession();
  updateBadge(null);
}

async function addSiteToActiveSession(domain) {
  const session = await getSession();
  if (!session || !session.active) return { ok: false, reason: "no_active_session" };
  if (session.sites.includes(domain)) return { ok: true, alreadyBlocked: true };

  // In blacklist mode this adds one more site to block; in whitelist mode it
  // adds one more site to the allow list (there's no other meaningful action
  // for "block this site now" once everything is already blocked by default).
  session.sites.push(domain);
  await setSession(session);
  await applyBlockRules(session.sites, session.mode);
  apiRequest("/api/extension/session/sites", {
    method: "PATCH",
    body: JSON.stringify({ sites: session.sites }),
  });
  return { ok: true, session };
}

function updateBadge(session) {
  if (session && session.active) {
    chrome.action.setBadgeText({ text: "\u25CF" }); // solid dot while a block is running
    chrome.action.setBadgeBackgroundColor({ color: "#0F6E56" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

// ---------- Backend sync (picks up sessions started from the website) ----------

async function syncWithBackend() {
  const local = await getSession();
  const remote = await apiRequest("/api/extension/session/status");

  // Profile sync (exam type etc.) is independent of session state - keeps
  // the blocked page's personalized audio current even between sessions.
  const profile = await apiRequest("/api/extension/profile");
  if (profile.ok && profile.data) {
    await chrome.storage.local.set({ revm2Profile: profile.data });
  }

  if (!remote.ok || !remote.data) return; // offline or not configured yet - keep local state as-is

  const remoteSession = remote.data.session;

  if (remoteSession?.active && !local?.active) {
    // Session was started on the website - mirror it here.
    await startSession({
      blockName: remoteSession.blockName,
      sites: remoteSession.sites,
      durationMinutes: remoteSession.durationMinutes ?? null,
      mode: remoteSession.mode,
    });
  } else if (!remoteSession?.active && local?.active) {
    // Session was ended remotely (e.g. from desktop companion later).
    await endSession("ended_remotely");
  }
}

// ---------- One-click connect (pushed from the website, no copy/paste) ----------
// The website calls chrome.runtime.sendMessage(EXTENSION_ID, {...}) after the
// user clicks "Connect extension". Only origins listed in manifest.json's
// externally_connectable.matches are allowed to reach this at all - anything
// else is silently ignored by Chrome before it gets here.
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === "RM2_PING") {
      // Lets the website detect "extension is installed" before showing the
      // Connect button, instead of guessing.
      sendResponse({ ok: true, installed: true, version: chrome.runtime.getManifest().version });
      return;
    }

    if (msg?.type === "RM2_STATUS") {
      // Lets the website know whether it still needs to connect at all -
      // used to auto-connect silently on page load instead of requiring a click.
      const settings = await getSettings();
      sendResponse({ ok: true, installed: true, connected: !!settings.token });
      return;
    }

    if (msg?.type === "RM2_CONNECT") {
      if (!msg.token) {
        sendResponse({ ok: false, reason: "missing_token" });
        return;
      }
      const partial = { token: msg.token };
      if (msg.apiBase) partial.apiBase = msg.apiBase;
      if (msg.webBase) partial.webBase = msg.webBase;
      await setSettings(partial);
      await syncWithBackend(); // pick up any session immediately instead of waiting up to 1 min
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "RM2_DISCONNECT") {
      await setSettings({ token: "" });
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "RM2_START_SESSION") {
      // Pushed the instant a block is created on the website, so blocking
      // applies right away instead of waiting for the next 1-minute poll.
      const settings = await getSettings();
      if (!settings.token) {
        sendResponse({ ok: false, reason: "not_connected" });
        return;
      }
      const session = await startSession(msg.payload);
      sendResponse({ ok: true, session });
      return;
    }

    if (msg?.type === "RM2_END_SESSION") {
      const settings = await getSettings();
      if (!settings.token) {
        sendResponse({ ok: false, reason: "not_connected" });
        return;
      }
      await endSession(msg.reason || "ended_remotely");
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, reason: "unknown_message" });
  })();
  return true; // keep the message channel open for the async response
});

// ---------- Adult content filter ----------
// Two static (network-level) layers, toggled together by the one "Block
// adult content" setting:
//   1. adult_blocklist        - ~25k exact known adult domains
//   2. adult_keyword_domains  - regex rules catching domains built around
//      common adult/porn-site naming patterns (xxx/porn/sex/hentai/tube
//      sites, plus common Hindi-transliteration terms used by text "story"
//      sites like Antarvasna and its many clones/mirrors) - this is what
//      catches new or rotating domains that aren't on the exact list yet.
// A fourth, content-level layer lives in content/adult-heuristic.js (keyword
// density in the page's own text) for sites whose domain name gives nothing
// away - e.g. a generic blogspot/wordpress URL hosting explicit stories.
// A fifth layer, content/rta-check.js, looks for the self-declared RTA tag.

const ADULT_RULESET_IDS = ["adult_blocklist", "adult_keyword_domains"];

async function setAdultBlockEnabled(enabled) {
  if (enabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ADULT_RULESET_IDS });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ADULT_RULESET_IDS });
  }
  await setSettings({ blockAdultContent: enabled });
}

// Chrome persists enabled-ruleset state across browser restarts, but NOT
// reliably across extension updates - so re-apply the saved preference
// every time the service worker (re)starts, rather than trusting the
// manifest's default "enabled": false to still reflect what the user chose.
async function reapplyAdultBlockState() {
  const settings = await getSettings();
  const enabledIds = await chrome.declarativeNetRequest.getEnabledRulesets();
  const allEnabled = ADULT_RULESET_IDS.every((id) => enabledIds.includes(id));
  const noneEnabled = ADULT_RULESET_IDS.every((id) => !enabledIds.includes(id));
  if (settings.blockAdultContent && !allEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ADULT_RULESET_IDS });
  } else if (!settings.blockAdultContent && !noneEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ADULT_RULESET_IDS });
  }
}

// ---------- Event wiring ----------

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 1 });
  reapplyAdultBlockState();
});

chrome.runtime.onStartup.addListener(() => {
  reapplyAdultBlockState();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM) {
    await syncWithBackend();
  }
  if (alarm.name === END_ALARM) {
    await endSession("completed");
  }
  if (alarm.name === "revm2-emergency-relock") {
    const session = await getSession();
    if (session?.active) await applyBlockRules(session.sites, session.mode);
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "START_SESSION": {
        const session = await startSession(msg.payload);
        sendResponse({ ok: true, session });
        break;
      }
      case "GET_STATUS": {
        const session = await getSession();
        sendResponse({ ok: true, session });
        break;
      }
      case "ADD_CURRENT_SITE": {
        const result = await addSiteToActiveSession(msg.domain);
        sendResponse(result);
        break;
      }
      case "SESSION_ENDED_EARLY": {
        // Sent from blocked.html once the unlock code is completed correctly.
        const session = await getSession();
        if (session) session.verified = false;
        await setSession(session);
        await endSession("manual_unlock");
        sendResponse({ ok: true });
        break;
      }
      case "EMERGENCY_UNLOCK_CONFIRMED": {
        // Sent after the website confirms the Rs.90 payment webhook-side
        // and hands back a short-lived token (validated in msg.payload).
        const session = await getSession();
        if (session) {
          session.verified = false;
          session.usedEmergencyUnlock = true;
          await setSession(session);
          await clearBlockRules();
          // Re-lock automatically after 30 minutes.
          await chrome.alarms.create("revm2-emergency-relock", {
            when: Date.now() + 30 * 60_000,
          });
        }
        sendResponse({ ok: true });
        break;
      }
      case "TOGGLE_ADULT_BLOCK": {
        await setAdultBlockEnabled(!!msg.enabled);
        sendResponse({ ok: true, enabled: !!msg.enabled });
        break;
      }
      case "GET_ADULT_BLOCK_STATE": {
        const settings = await getSettings();
        sendResponse({ ok: true, enabled: !!settings.blockAdultContent });
        break;
      }
      default:
        sendResponse({ ok: false, reason: "unknown_message" });
    }
  })();
  return true; // keep the message channel open for the async response
});
