blocked-voice.mp3 - plays automatically when a blocked page loads.
If this file is missing, the page falls back to the browser's
built-in voice reading a generic line - nothing breaks either way.

To swap the clip later, just replace this file (keep the same
filename) - no code changes needed.
