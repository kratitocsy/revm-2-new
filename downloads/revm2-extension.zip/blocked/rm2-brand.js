/* RevM2 brand assets for the extension's blocked page.
   Ported from the website's shared.js (starfield canvas + animated
   logo SVG) so this renders identically without needing a live
   network fetch to revm2.app - a blocked page has to work offline. */

function initStarfield(canvasId = "starfield", count = 240) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener("resize", resize);
  const stars = Array.from({ length: count }, () => ({
    x: Math.random(),
    y: Math.random(),
    r: Math.random() * 1.1 + 0.15,
    a: Math.random() * 0.65 + 0.1,
    s: Math.random() * 0.0003 + 0.00008,
  }));
  let t = 0;
  (function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    t++;
    for (const s of stars) {
      const alpha = Math.max(0, s.a + Math.sin(t * s.s * 60 + s.x * 100) * 0.18);
      ctx.beginPath();
      ctx.arc(s.x * canvas.width, s.y * canvas.height, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.fill();
    }
    requestAnimationFrame(draw);
  })();
}

function buildLogoSVG(size) {
  const id = "L" + Math.random().toString(36).slice(2, 7);
  return `<svg class="rm2-svg rm2-svg--${size}" viewBox="0 0 690 210"
      xmlns="http://www.w3.org/2000/svg" fill="none"
      role="img" aria-label="RevM\u00b2">
    <defs>
      <linearGradient id="${id}g1" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="rgba(255,255,255,0)"/>
        <stop offset="40%" stop-color="rgba(255,255,255,0.45)"/>
        <stop offset="100%" stop-color="rgba(255,255,255,0.92)"/>
      </linearGradient>
      <radialGradient id="${id}fl" cx="50%" cy="0%" r="100%">
        <stop offset="0%" stop-color="#ff9a3c"/>
        <stop offset="55%" stop-color="#c8a96e"/>
        <stop offset="100%" stop-color="rgba(200,169,110,0)"/>
      </radialGradient>
    </defs>
    <text x="18" y="148" font-family="Inter,Arial,sans-serif" font-weight="900" font-size="130" font-style="italic" letter-spacing="-4" fill="white">REV</text>
    <text x="298" y="148" font-family="Inter,Arial,sans-serif" font-weight="900" font-size="130" letter-spacing="-4" fill="white">M</text>
    <line x1="432" y1="24" x2="474" y2="86" stroke="white" stroke-width="14" stroke-linecap="square"/>
    <line x1="478" y1="24" x2="428" y2="86" stroke="white" stroke-width="6" stroke-linecap="square"/>
    <rect x="424" y="88" width="58" height="9" fill="#c8a96e"/>
    <text x="484" y="42" font-family="Inter,Arial,sans-serif" font-weight="900" font-size="32" fill="white">2</text>
    <path d="M 40 165 Q 180 210 340 138 Q 450 82 524 30" stroke="url(#${id}g1)" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-dasharray="600" stroke-dashoffset="600">
      <animate attributeName="stroke-dashoffset" from="600" to="0" dur="1.5s" begin="0.1s" fill="freeze" calcMode="spline" keySplines="0.4 0 0.2 1"/>
    </path>
    <path id="${id}path" d="M 40 165 Q 180 210 340 138 Q 450 82 516 20" fill="none" stroke="none" visibility="hidden"/>
    <g id="${id}rkt">
      <g opacity="1">
        <ellipse cx="0" cy="12" rx="4" ry="9" fill="url(#${id}fl)" opacity="0.85">
          <animate attributeName="ry" values="9;5;10;6;9" dur="0.16s" repeatCount="indefinite"/>
          <animate attributeName="opacity" values="0.85;0.5;0.9;0.55;0.85" dur="0.2s" repeatCount="indefinite"/>
        </ellipse>
        <animate attributeName="opacity" from="1" to="0" begin="${id}rkt.animateMotion.end" dur="0.4s" fill="freeze"/>
      </g>
      <rect x="-6" y="-24" width="12" height="24" rx="2" fill="white"/>
      <polygon points="-6,-24 6,-24 0,-36" fill="white"/>
      <polygon points="-6,-6 -6,2 -13,2" fill="white"/>
      <polygon points="6,-6 6,2 13,2" fill="white"/>
      <circle cx="0" cy="-15" r="3" fill="#000"/>
      <rect x="-3" y="0" width="6" height="8" rx="1" fill="#c8a96e"/>
      <animateMotion id="${id}rkt.animateMotion" dur="1.4s" begin="0s" fill="freeze" calcMode="spline" keySplines="0.25 0.1 0.25 1" keyPoints="0;1" keyTimes="0;1" rotate="auto">
        <mpath href="#${id}path"/>
      </animateMotion>
      <animateTransform attributeName="transform" type="translate" values="0,0; 0,-2.5; 0,0; 0,-1.5; 0,0" dur="2.8s" begin="${id}rkt.animateMotion.end" repeatCount="indefinite" additive="sum"/>
    </g>
  </svg>`;
}

function injectLogoCSS() {
  if (document.getElementById("rm2-logo-css")) return;
  const s = document.createElement("style");
  s.id = "rm2-logo-css";
  s.textContent = `
    .rm2-logo{display:inline-block;line-height:0;}
    .rm2-svg{display:block;}
    .rm2-svg--small{width:100px;height:auto;}
  `;
  document.head.appendChild(s);
}

function mountLogo() {
  injectLogoCSS();
  document.querySelectorAll(".rm2-logo").forEach((el) => {
    el.innerHTML = buildLogoSVG(el.dataset.size || "small");
  });
}

function wireMuteButton() {
  const btn = document.getElementById("mute-btn");
  if (!btn) return;
  const render = () => {
    btn.textContent = isBlockedAudioOn() ? "\uD83D\uDD0A" : "\uD83D\uDD07";
  };
  render();
  btn.addEventListener("click", () => {
    const next = !isBlockedAudioOn();
    try {
      localStorage.setItem("rm2_sound", JSON.stringify(next));
    } catch {}
    render();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initStarfield();
  mountLogo();
  wireMuteButton();
  playBlockedAudio();
});

/* ── BLOCKED-PAGE AUDIO ────────────────────────────────────
   Plays one shared clip on every blocked page. Falls back to the
   browser's built-in speech synthesis if the file is missing or
   autoplay is blocked, so this never silently does nothing. */

const BLOCKED_VOICE_FILE = "audio/blocked-voice.mp3";
const BLOCKED_VOICE_FALLBACK_TEXT = "This site is blocked. Your future will thank you.";

async function playBlockedAudio() {
  if (!isBlockedAudioOn()) return;

  const audio = new Audio(chrome.runtime.getURL(`blocked/${BLOCKED_VOICE_FILE}`));
  audio.volume = 0.85;

  audio.addEventListener("error", () => speakFallback(BLOCKED_VOICE_FALLBACK_TEXT));
  try {
    await audio.play();
  } catch {
    // File missing, or browser blocked autoplay - speak it instead.
    speakFallback(BLOCKED_VOICE_FALLBACK_TEXT);
  }
}

function speakFallback(text) {
  if (!("speechSynthesis" in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = 0.95;
  utter.pitch = 1;
  speechSynthesis.speak(utter);
}

function isBlockedAudioOn() {
  // Reuses the same localStorage key convention as the website's
  // sound toggle (rm2_sound) so muting one place mutes both.
  try {
    const v = localStorage.getItem("rm2_sound");
    return v === null ? true : JSON.parse(v) !== false;
  } catch {
    return true;
  }
}
