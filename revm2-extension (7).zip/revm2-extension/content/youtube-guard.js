// RevM2 - YouTube channel-level enforcement.
//
// The domain-level rules in background.js (declarativeNetRequest) can only
// block or allow the whole of youtube.com - they have no idea which channel
// a video belongs to, because that's SPA content, not something that shows
// up as a separate request Chrome's network layer can filter on. This script
// fills that gap: it runs on every youtube.com page, works out which channel
// the person is currently looking at, and checks it against the active
// session's `youtubeRules` (set from the website's "YouTube channels" panel,
// synced down like everything else in revm2Session).
//
// youtubeRules shape:
//   { mode: "block" | "allow", channels: [{ id, label }] }
//   - "block": the listed channels are off-limits; everything else on
//     youtube.com stays reachable.
//   - "allow": ONLY the listed channels are reachable; the home feed,
//     search, Shorts feed, and any other channel are redirected.
//   `id` is whatever normalizeChannelRef() below produces - a bare channel
//   ID (UC...), an @handle, or a legacy /c/ or /user/ slug, always lowercase
//   and without a leading punctuation.
//
// Exceptions in "allow" mode:
//   - Home feed ("/") always stays reachable - otherwise there'd be
//     nowhere to even start a search from.
//   - Search results ("/results") stays reachable ONLY if the search query
//     itself matches a listed channel (by name or handle/id, case- and
//     word-order-insensitive) - see searchQueryMatchesListedChannel()
//     below. A search for anything else (unrelated terms, or another
//     channel's name) is blocked right on the results page, before the
//     person can even click into it.
// Clicking through into an actual video/channel page is always checked
// against the listed channels regardless of how it was reached, so this
// is a belt-and-braces layer on top of that, not a replacement for it.

(function () {
  if (window.top !== window) return; // only the top frame - embeds fire this too, and duplicate work

  let lastChecked = null; // dedupe: SPA nav events can fire more than once per real navigation

  function normalizeChannelRef(raw) {
    if (!raw) return "";
    let v = String(raw).trim().toLowerCase();
    v = v.replace(/^https?:\/\/(www\.|m\.)?youtube\.com\//, "");
    v = v.replace(/^@/, "@"); // keep the @ for handles, just normalize case above
    v = v.replace(/\/$/, "");
    v = v.split(/[?#]/)[0];
    // Collapse known path prefixes down to the bare identifier.
    v = v.replace(/^channel\//, "");
    v = v.replace(/^c\//, "");
    v = v.replace(/^user\//, "");
    return v;
  }

  // Pulls every identifier the current page exposes for "which channel is
  // this" - a video's watch page doesn't put the channel in the URL, so this
  // has to look at the DOM/embedded JSON instead of just location.pathname.
  function currentPageChannelRefs() {
    const refs = new Set();
    const path = location.pathname;

    // Direct channel/handle pages - identifier is right there in the URL.
    const directMatch = path.match(/^\/(channel\/UC[\w-]+|c\/[\w.-]+|user\/[\w.-]+|@[\w.-]+)/i);
    if (directMatch) refs.add(normalizeChannelRef(directMatch[1]));

    // Canonical link - present on watch pages and set to the channel URL on
    // channel pages, so this covers both.
    const canonical = document.querySelector('link[rel="canonical"]')?.href;
    if (canonical) refs.add(normalizeChannelRef(canonical));

    // itemprop channelId - present on watch pages once the player metadata
    // is in the DOM.
    const metaChannelId = document.querySelector('meta[itemprop="channelId"]')?.content;
    if (metaChannelId) refs.add(normalizeChannelRef(metaChannelId));

    // Owner link in the video description area (renders slightly later than
    // the meta tags above, so this is a second chance to catch it).
    const ownerLink = document.querySelector(
      "ytd-video-owner-renderer a.yt-simple-endpoint, #owner a.yt-simple-endpoint"
    )?.getAttribute("href");
    if (ownerLink) refs.add(normalizeChannelRef(ownerLink));

    // Last resort: scan the embedded page-data script for a channelId/handle
    // pair. This is a plain regex scan, not a JSON.parse of the whole blob -
    // ytInitialData is large and its shape shifts often, and all this needs
    // is "does this string contain a channel identifier anywhere".
    if (refs.size === 0) {
      for (const script of document.querySelectorAll("script")) {
        const text = script.textContent;
        if (!text || !text.includes("channelId")) continue;
        const idMatch = text.match(/"channelId":"(UC[\w-]{20,})"/);
        if (idMatch) refs.add(normalizeChannelRef(idMatch[1]));
        const handleMatch = text.match(/"canonicalBaseUrl":"\/(@[\w.-]+)"/);
        if (handleMatch) refs.add(normalizeChannelRef(handleMatch[1]));
        if (refs.size) break;
      }
    }

    refs.delete("");
    return refs;
  }

  // Pulls the channel's human-readable DISPLAY NAME off the page (e.g.
  // "Eduniti"), separately from currentPageChannelRefs()'s handles/IDs.
  //
  // Someone adding a channel to their allow/block list on the website has
  // no reason to already know its @handle - they know it as "Eduniti", not
  // "@mohitgoenka99". If they type the display name, normalizeChannelRef()
  // stores it as a literal id ("eduniti") that will never equal any of the
  // real identifiers a video page exposes. That made search results look
  // right (search matching is already loose, word-based) while clicking
  // into the actual video got blocked anyway - confusing, and the
  // displayed name is right there on the page the whole time. This closes
  // that gap by feeding the display name through the same loose word-match
  // used for search queries (see searchQueryMatchesListedChannel).
  function currentPageChannelNames() {
    const names = new Set();

    // Present on watch pages once player metadata has loaded - the most
    // reliable source, exact display name as YouTube itself renders it.
    const metaName = document.querySelector('span[itemprop="author"] link[itemprop="name"]')?.content;
    if (metaName) names.add(metaName);

    // Owner renderer under the video - renders slightly later than the
    // meta tag above, so this is a second chance to catch it.
    const ownerText = document.querySelector(
      "ytd-video-owner-renderer ytd-channel-name #text, #owner #channel-name #text, #owner ytd-channel-name yt-formatted-string"
    )?.textContent;
    if (ownerText) names.add(ownerText);

    // Channel page header (visiting the channel's own /@handle page
    // directly, not a video).
    const channelHeaderText = document.querySelector(
      "ytd-channel-name #text, #channel-name #text"
    )?.textContent;
    if (channelHeaderText) names.add(channelHeaderText);

    // Last resort, mirrors the channelId regex scan above - embedded
    // page-data JSON almost always has an "author":"..." field on watch
    // pages.
    if (names.size === 0) {
      for (const script of document.querySelectorAll("script")) {
        const text = script.textContent;
        if (!text || !text.includes('"author"')) continue;
        const m = text.match(/"author":"([^"]{1,100})"/);
        if (m) names.add(m[1]);
        if (names.size) break;
      }
    }

    names.delete("");
    return names;
  }

  // True if any of the page's display names is "about" one of the listed
  // channels, using the exact same loose word-match as search queries -
  // every word of one side appears in the other, order-independent,
  // case-insensitive. Lets a channel added by typed display name ("eduniti")
  // still match the real page even though it's not an exact handle/id.
  function nameMatchesListedChannel(names, channels) {
    for (const name of names) {
      const nameWords = wordsOf(name);
      if (nameWords.length === 0) continue;
      for (const c of channels) {
        const labelWords = wordsOf(c.label);
        const idWords = wordsOf(String(c.id || "").replace(/^@/, ""));
        if (
          containsAllWords(labelWords, nameWords) ||
          containsAllWords(nameWords, labelWords) ||
          containsAllWords(idWords, nameWords) ||
          containsAllWords(nameWords, idWords)
        ) {
          return true;
        }
      }
    }
    return false;
  }

  // Home feed - always reachable in "allow" mode, full stop.
  function isHomePage() {
    const path = location.pathname.replace(/\/+$/, "") || "/";
    return path === "/";
  }

  function isSearchResultsPage() {
    const path = location.pathname.replace(/\/+$/, "") || "/";
    return path === "/results";
  }

  // Loose text match: lowercase, collapse anything that isn't a letter or
  // digit down to single spaces, split into words. Case never matters;
  // what matters is whether the same words appear in the same order.
  function normalizeForMatch(raw) {
    return String(raw || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function wordsOf(raw) {
    const normalized = normalizeForMatch(raw);
    return normalized ? normalized.split(" ") : [];
  }

  // True if every word in `needle` also appears somewhere in `haystack`
  // (order doesn't matter, e.g. "gaming mrbeast" and "mrbeast gaming"
  // count the same) - but each is still whole-word matching, not a
  // character-substring check, so a search for "mr" won't match a channel
  // called "MrBeast" just because "mr" is a substring of it.
  function containsAllWords(haystackWords, needleWords) {
    if (needleWords.length === 0) return false;
    const haystackSet = new Set(haystackWords);
    return needleWords.every((w) => haystackSet.has(w));
  }

  // True if the current /results page's search query is "about" one of the
  // listed channels - either every word of the query shows up in the
  // channel's name/handle, or every word of the channel's name/handle
  // shows up in the query (covers typing extra words around the channel
  // name). Word order never matters, only which words are present.
  // Case-insensitive throughout. Anything else - a generic topic search,
  // or clearly a *different* channel's name - fails this and gets blocked
  // right on the results page.
  function searchQueryMatchesListedChannel(channels) {
    const params = new URLSearchParams(location.search);
    const rawQuery = params.get("search_query") || params.get("q") || "";
    const queryWords = wordsOf(rawQuery);
    if (queryWords.length === 0) return false; // no query at all - nothing to justify being here

    return channels.some((c) => {
      const labelWords = wordsOf(c.label);
      const idWords = wordsOf(String(c.id || "").replace(/^@/, ""));
      return (
        containsAllWords(labelWords, queryWords) ||
        containsAllWords(queryWords, labelWords) ||
        containsAllWords(idWords, queryWords) ||
        containsAllWords(queryWords, idWords)
      );
    });
  }

  function goToBlockedPage(reasonSite) {
    const url = chrome.runtime.getURL(
      `blocked/blocked.html?site=${encodeURIComponent(reasonSite)}&youtube=1`
    );
    window.location.replace(url);
  }

  async function evaluate() {
    if (lastChecked === location.href) return;
    lastChecked = location.href;

    const { revm2Session } = await chrome.storage.local.get("revm2Session");
    const rules = revm2Session?.active ? revm2Session.youtubeRules : null;
    if (!rules || !Array.isArray(rules.channels) || rules.channels.length === 0) return;

    const listed = new Set(rules.channels.map((c) => normalizeChannelRef(c.id)));
    const refs = currentPageChannelRefs();
    const names = currentPageChannelNames();
    const onListedChannel =
      [...refs].some((r) => listed.has(r)) || nameMatchesListedChannel(names, rules.channels);

    if (rules.mode === "allow") {
      // "allow" mode - only a listed channel's own pages stay reachable,
      // plus two deliberate exceptions:
      //   1. the home feed, always
      //   2. the search results page, but ONLY if the query itself is
      //      about a listed channel (see searchQueryMatchesListedChannel)
      // Everything else not on the list - Shorts feed, another channel's
      // page, a video from another channel, or an off-topic/other-channel
      // search - still gets blocked.
      const allowedHere =
        onListedChannel ||
        isHomePage() ||
        (isSearchResultsPage() && searchQueryMatchesListedChannel(rules.channels));
      if (!allowedHere) {
        goToBlockedPage(refs.values().next().value || location.hostname);
      }
    } else {
      // "block" mode - only stop the specific listed channels; navigation
      // surfaces (home, search, etc.) are left alone.
      if (onListedChannel) goToBlockedPage(refs.values().next().value || location.hostname);
    }
  }

  // Initial load.
  evaluate();
  // Re-check once the DOM settles, since watch-page channel metadata often
  // isn't present yet at document_start/document_end.
  document.addEventListener("DOMContentLoaded", evaluate);
  window.addEventListener("load", evaluate);
  // YouTube is a single-page app - it swaps content via the History API
  // instead of doing real navigations, so declarativeNetRequest never
  // re-fires and even document_end only runs once per real page load.
  // YouTube's own front-end dispatches this event after every internal
  // navigation finishes rendering, which is exactly the hook needed here.
  window.addEventListener("yt-navigate-finish", () => {
    // Give the new page's metadata a beat to land in the DOM.
    setTimeout(evaluate, 150);
  });

  // A tab that's already sitting open on some channel BEFORE a session
  // (or a mid-session edit to youtubeRules) starts never fires any of the
  // events above - nothing navigates, nothing loads. Left alone, someone
  // could just have the disallowed channel open in a background tab the
  // whole time and it would never get caught. storage.onChanged fires the
  // moment background.js writes the new revm2Session (session start, end,
  // or a rules update mid-session via addYoutubeChannelToActiveSession),
  // so force a fresh check right then - reset lastChecked since the URL
  // itself hasn't changed, only the rules being checked against it have.
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.revm2Session) return;
    lastChecked = null;
    evaluate();
  });
})();
