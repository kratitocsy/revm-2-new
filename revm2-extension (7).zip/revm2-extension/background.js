// RevM2 - background service worker (MV3)
import {
  getSession,
  setSession,
  clearSession,
  apiRequest,
  getSettings,
  setSettings,
} from "./utils/storage.js";

// Dynamic rule ID ranges - kept clear of each other and of any static rules
// (adult_blocklist / adult_keyword_domains live in separate static rulesets
// and don't use dynamic IDs at all).
const BLACKLIST_RULE_ID_BASE = 20000; // one redirect rule per blocked domain (20000-20999)
const WHITELIST_CATCHALL_ID = 21000; // single rule: redirect every main_frame nav by default
const WHITELIST_ALLOW_ID_BASE = 21001; // one allow rule per whitelisted domain (21001-21999)
const DYNAMIC_RULE_RANGE_START = BLACKLIST_RULE_ID_BASE;
const DYNAMIC_RULE_RANGE_END = WHITELIST_ALLOW_ID_BASE + 999; // 21999

const SYNC_ALARM = "revm2-sync";
const END_ALARM = "revm2-session-end";

// ---------- Blocking rules ----------

// Domains that stay reachable even in whitelist mode, regardless of what the
// person typed - so a strict "allow only these sites" block can never lock
// them out of the RevM2 site itself (needed to end the session, pay for an
// emergency unlock, etc.) or basic local dev testing.
function alwaysAllowedDomains(settings) {
  const out = new Set(["revm2.app", "localhost", "127.0.0.1"]);
  const fromUrl = (u) => {
    try {
      out.add(new URL(u).hostname.replace(/^www\./, ""));
    } catch {}
  };
  if (settings?.webBase) fromUrl(settings.webBase);
  if (settings?.apiBase) fromUrl(settings.apiBase);
  return Array.from(out);
}

function hostMatchesDomain(host, domain) {
  return host === domain || host.endsWith(`.${domain}`);
}

function urlHost(urlStr) {
  try {
    return new URL(urlStr).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function computeAllowHosts(sites, mode, settings) {
  const siteHosts = sites.map((s) => s.replace(/^www\./, ""));
  const allowHosts =
    mode === "whitelist"
      ? [...siteHosts, ...alwaysAllowedDomains(settings).map((d) => d.replace(/^www\./, ""))]
      : [];
  return { siteHosts, allowHosts };
}

function shouldBlockUrl(urlStr, siteHosts, allowHosts, mode) {
  if (!/^https?:\/\//i.test(urlStr)) return false;
  const host = urlHost(urlStr);
  if (!host) return false;
  return mode === "whitelist"
    ? !allowHosts.some((d) => hostMatchesDomain(host, d))
    : siteHosts.some((d) => hostMatchesDomain(host, d));
}

// declarativeNetRequest rules only fire on a NEW navigation - a tab that was
// already open before a block/allow-list started won't get touched until it
// happens to reload (and single-page apps like Gmail mostly never do a full
// reload at all once loaded, so their main_frame rule almost never re-fires
// after the first load). Sweeping already-open tabs and sending the blocked
// ones to the blocked page closes that gap instead of relying on the person
// to notice and manually reload every tab themselves.
async function redirectAlreadyOpenTabs(sites, mode) {
  const settings = await getSettings();
  const { siteHosts, allowHosts } = computeAllowHosts(sites, mode, settings);

  let tabs;
  try {
    tabs = await chrome.tabs.query({});
  } catch {
    return; // "tabs" permission unavailable in this context - nothing to sweep
  }

  for (const tab of tabs) {
    if (!tab.id || !tab.url) continue;
    if (shouldBlockUrl(tab.url, siteHosts, allowHosts, mode)) {
      const host = urlHost(tab.url);
      const target = chrome.runtime.getURL(
        `blocked/blocked.html?site=${encodeURIComponent(host || "")}&mode=${mode}`
      );
      chrome.tabs.update(tab.id, { url: target }).catch(() => {});
    }
  }
}


async function applyBlockRules(sites, mode = "blacklist") {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds = existing
    .filter((r) => r.id >= DYNAMIC_RULE_RANGE_START && r.id <= DYNAMIC_RULE_RANGE_END)
    .map((r) => r.id);

  let addRules;

  if (mode === "whitelist") {
    const settings = await getSettings();
    const allowDomains = Array.from(new Set([...sites, ...alwaysAllowedDomains(settings)])).slice(
      0,
      999
    );

    // Catch-all: redirect every top-level navigation by default. Deliberately
    // uses a plain condition with NO urlFilter/regexFilter at all (which in
    // declarativeNetRequest means "matches every URL" for the given
    // resourceTypes) rather than a regex-capture trick to show the exact
    // blocked domain - that's cosmetic, and a rule this critical (it's what
    // makes whitelist mode actually block anything) needs to be the
    // simplest, most reliable thing possible rather than clever.
    const catchAll = {
      id: WHITELIST_CATCHALL_ID,
      priority: 1,
      action: {
        type: "redirect",
        redirect: {
          extensionPath: "/blocked/blocked.html?mode=whitelist",
        },
      },
      condition: {
        resourceTypes: ["main_frame"],
      },
    };

    // Per-domain allow rules, given higher priority so they win over the
    // catch-all above for anything on the allow list (requestDomains also
    // matches subdomains automatically).
    const allowRules = allowDomains.map((domain, i) => ({
      id: WHITELIST_ALLOW_ID_BASE + i,
      priority: 2,
      action: { type: "allow" },
      condition: {
        requestDomains: [domain],
        resourceTypes: ["main_frame"],
      },
    }));

    addRules = [catchAll, ...allowRules];
  } else {
    addRules = sites.map((domain, i) => ({
      id: BLACKLIST_RULE_ID_BASE + i,
      priority: 1,
      action: {
        type: "redirect",
        redirect: {
          extensionPath: `/blocked/blocked.html?site=${encodeURIComponent(domain)}&mode=blacklist`,
        },
      },
      condition: {
        requestDomains: [domain],
        resourceTypes: ["main_frame"],
      },
    }));
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules,
  });
}

async function clearBlockRules() {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds = existing
    .filter((r) => r.id >= DYNAMIC_RULE_RANGE_START && r.id <= DYNAMIC_RULE_RANGE_END)
    .map((r) => r.id);
  if (removeIds.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: removeIds });
  }
}

// ---------- Session lifecycle ----------

async function startSession({ blockName, sites, durationMinutes, mode }) {
  const startedAt = new Date().toISOString();
  const unlimited = !durationMinutes;
  const endsAt = unlimited
    ? null
    : new Date(Date.now() + durationMinutes * 60_000).toISOString();

  // "blacklist" (default) = block just these sites, everything else stays
  // reachable. "whitelist" = only these sites stay reachable, everything
  // else gets redirected to the blocked page. Anything unrecognized falls
  // back to blacklist, so older sessions synced from the website (which may
  // not send `mode` yet) keep working exactly as before.
  const resolvedMode = mode === "whitelist" ? "whitelist" : "blacklist";

  const session = {
    active: true,
    blockName,
    sites,
    mode: resolvedMode,
    startedAt,
    endsAt,
    unlimited,
    verified: true, // downgraded to false if the person uses the manual code or emergency unlock
    usedEmergencyUnlock: false,
  };

  // Apply the actual browser-level rules FIRST, before persisting the
  // session as "active". If this throws, we deliberately let it propagate
  // (see the message handlers below) rather than silently leaving a
  // session marked active in storage while nothing is actually being
  // blocked - a session that *looks* active but isn't enforced is worse
  // than one that visibly failed to start.
  await applyBlockRules(sites, resolvedMode);
  await setSession(session);
  redirectAlreadyOpenTabs(sites, resolvedMode); // don't block on this - it's a cleanup pass

  if (endsAt) {
    await chrome.alarms.create(END_ALARM, { when: new Date(endsAt).getTime() });
  } else {
    await chrome.alarms.clear(END_ALARM);
  }

  // Best-effort sync so the website / Live Grid can show the session
  // (and, later, the verified badge) as soon as it starts.
  apiRequest("/api/extension/session/start", {
    method: "POST",
    body: JSON.stringify(session),
  });

  updateBadge(session);
  return session;
}

async function endSession(reason) {
  const session = await getSession();
  if (!session) return;

  await clearBlockRules();
  await chrome.alarms.clear(END_ALARM);

  const verified = session.verified && reason === "completed";

  apiRequest("/api/extension/session/end", {
    method: "POST",
    body: JSON.stringify({ reason, verified }),
  });

  await clearSession();
  updateBadge(null);
}

async function addSiteToActiveSession(domain) {
  const session = await getSession();
  if (!session || !session.active) return { ok: false, reason: "no_active_session" };
  if (session.sites.includes(domain)) return { ok: true, alreadyBlocked: true };

  // In blacklist mode this adds one more site to block; in whitelist mode it
  // adds one more site to the allow list (there's no other meaningful action
  // for "block this site now" once everything is already blocked by default).
  const previousSites = [...session.sites];
  session.sites.push(domain);
  try {
    await applyBlockRules(session.sites, session.mode);
  } catch (err) {
    console.error("RevM2: failed to update block rules", err);
    return { ok: false, reason: "apply_rules_failed", error: String(err?.message || err) };
  }
  await setSession(session);
  redirectAlreadyOpenTabs(session.sites, session.mode); // don't block on this - it's a cleanup pass
  apiRequest("/api/extension/session/sites", {
    method: "PATCH",
    body: JSON.stringify({ sites: session.sites }),
  });
  return { ok: true, session };
}

function updateBadge(session) {
  if (session && session.active) {
    chrome.action.setBadgeText({ text: "\u25CF" }); // solid dot while a block is running
    chrome.action.setBadgeBackgroundColor({ color: "#0F6E56" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

// ---------- Backend sync (picks up sessions started from the website) ----------

async function syncWithBackend() {
  const local = await getSession();
  const remote = await apiRequest("/api/extension/session/status");

  // Profile sync (exam type etc.) is independent of session state - keeps
  // the blocked page's personalized audio current even between sessions.
  const profile = await apiRequest("/api/extension/profile");
  if (profile.ok && profile.data) {
    await chrome.storage.local.set({ revm2Profile: profile.data });
  }

  if (!remote.ok || !remote.data) return; // offline or not configured yet - keep local state as-is

  const remoteSession = remote.data.session;

  if (remoteSession?.active && !local?.active) {
    // Session was started on the website - mirror it here.
    await startSession({
      blockName: remoteSession.blockName,
      sites: remoteSession.sites,
      durationMinutes: remoteSession.durationMinutes ?? null,
      mode: remoteSession.mode,
    });
  } else if (!remoteSession?.active && local?.active) {
    // Session was ended remotely (e.g. from desktop companion later).
    await endSession("ended_remotely");
  }
}

// ---------- One-click connect (pushed from the website, no copy/paste) ----------
// The website calls chrome.runtime.sendMessage(EXTENSION_ID, {...}) after the
// user clicks "Connect extension". Only origins listed in manifest.json's
// externally_connectable.matches are allowed to reach this at all - anything
// else is silently ignored by Chrome before it gets here.
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === "RM2_PING") {
      // Lets the website detect "extension is installed" before showing the
      // Connect button, instead of guessing.
      sendResponse({ ok: true, installed: true, version: chrome.runtime.getManifest().version });
      return;
    }

    if (msg?.type === "RM2_STATUS") {
      // Lets the website know whether it still needs to connect at all -
      // used to auto-connect silently on page load instead of requiring a click.
      const settings = await getSettings();
      sendResponse({ ok: true, installed: true, connected: !!settings.token });
      return;
    }

    if (msg?.type === "RM2_CONNECT") {
      if (!msg.token) {
        sendResponse({ ok: false, reason: "missing_token" });
        return;
      }
      const partial = { token: msg.token };
      if (msg.apiBase) partial.apiBase = msg.apiBase;
      if (msg.webBase) partial.webBase = msg.webBase;
      await setSettings(partial);
      await syncWithBackend(); // pick up any session immediately instead of waiting up to 1 min
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "RM2_DISCONNECT") {
      await setSettings({ token: "" });
      sendResponse({ ok: true });
      return;
    }

    if (msg?.type === "RM2_START_SESSION") {
      // Pushed the instant a block is created on the website, so blocking
      // applies right away instead of waiting for the next 1-minute poll.
      const settings = await getSettings();
      if (!settings.token) {
        sendResponse({ ok: false, reason: "not_connected" });
        return;
      }
      try {
        const session = await startSession(msg.payload);
        sendResponse({ ok: true, session });
      } catch (err) {
        console.error("RevM2: failed to start session", err);
        sendResponse({ ok: false, reason: "apply_rules_failed", error: String(err?.message || err) });
      }
      return;
    }

    if (msg?.type === "RM2_END_SESSION") {
      const settings = await getSettings();
      if (!settings.token) {
        sendResponse({ ok: false, reason: "not_connected" });
        return;
      }
      await endSession(msg.reason || "ended_remotely");
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, reason: "unknown_message" });
  })();
  return true; // keep the message channel open for the async response
});

// ---------- Adult content filter ----------
// Two static (network-level) layers, toggled together by the one "Block
// adult content" setting:
//   1. adult_blocklist        - ~25k exact known adult domains
//   2. adult_keyword_domains  - regex rules catching domains built around
//      common adult/porn-site naming patterns (xxx/porn/sex/hentai/tube
//      sites, plus common Hindi-transliteration terms used by text "story"
//      sites like Antarvasna and its many clones/mirrors) - this is what
//      catches new or rotating domains that aren't on the exact list yet.
// A fourth, content-level layer lives in content/adult-heuristic.js (keyword
// density in the page's own text) for sites whose domain name gives nothing
// away - e.g. a generic blogspot/wordpress URL hosting explicit stories.
// A fifth layer, content/rta-check.js, looks for the self-declared RTA tag.

const ADULT_RULESET_IDS = ["adult_blocklist", "adult_keyword_domains"];

async function setAdultBlockEnabled(enabled) {
  if (enabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ADULT_RULESET_IDS });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ADULT_RULESET_IDS });
  }
  await setSettings({ blockAdultContent: enabled });
}

// Chrome persists enabled-ruleset state across browser restarts, but NOT
// reliably across extension updates - so re-apply the saved preference
// every time the service worker (re)starts, rather than trusting the
// manifest's default "enabled": false to still reflect what the user chose.
async function reapplyAdultBlockState() {
  const settings = await getSettings();
  const enabledIds = await chrome.declarativeNetRequest.getEnabledRulesets();
  const allEnabled = ADULT_RULESET_IDS.every((id) => enabledIds.includes(id));
  const noneEnabled = ADULT_RULESET_IDS.every((id) => !enabledIds.includes(id));
  if (settings.blockAdultContent && !allEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ADULT_RULESET_IDS });
  } else if (!settings.blockAdultContent && !noneEnabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ADULT_RULESET_IDS });
  }
}

// ---------- Event wiring ----------

chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 1 });
  reapplyAdultBlockState();
  // Reloading/updating the extension (e.g. loading a new build over an old
  // one) does NOT fire onStartup - only a real browser restart does. So a
  // tab that was already open before the update, for a session that was
  // already active, would otherwise never get swept until it happened to
  // reload on its own. Re-apply and re-sweep here too.
  const session = await getSession();
  if (session?.active) {
    await applyBlockRules(session.sites, session.mode);
    redirectAlreadyOpenTabs(session.sites, session.mode);
  }
});

chrome.runtime.onStartup.addListener(async () => {
  reapplyAdultBlockState();
  const session = await getSession();
  if (session?.active) redirectAlreadyOpenTabs(session.sites, session.mode);
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM) {
    await syncWithBackend();
  }
  if (alarm.name === END_ALARM) {
    await endSession("completed");
  }
  if (alarm.name === "revm2-emergency-relock") {
    const session = await getSession();
    if (session?.active) {
      await applyBlockRules(session.sites, session.mode);
      redirectAlreadyOpenTabs(session.sites, session.mode);
    }
  }
});

// declarativeNetRequest only sees real network requests. Two common things
// never generate one, so they'd otherwise slip straight past every rule
// above:
//   - Back/forward-cache restores (hitting the back/forward button, or Chrome
//     waking a suspended tab) - the page is restored from memory, not
//     re-fetched.
//   - Single-page apps changing the URL via the History API (pushState) -
//     no navigation, no request, just a URL bar change.
// Both of those DO fire chrome.tabs.onUpdated with a changed `url`, though -
// so watch for that continuously (not just at fixed checkpoints like session
// start) for as long as a session is active, and force-redirect on the spot.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const session = await getSession();
  if (!session?.active) return;

  const settings = await getSettings();
  const { siteHosts, allowHosts } = computeAllowHosts(session.sites, session.mode, settings);
  if (!shouldBlockUrl(changeInfo.url, siteHosts, allowHosts, session.mode)) return;

  const host = urlHost(changeInfo.url);
  const target = chrome.runtime.getURL(
    `blocked/blocked.html?site=${encodeURIComponent(host || "")}&mode=${session.mode}`
  );
  chrome.tabs.update(tabId, { url: target }).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "START_SESSION": {
        try {
          const session = await startSession(msg.payload);
          sendResponse({ ok: true, session });
        } catch (err) {
          console.error("RevM2: failed to start session", err);
          sendResponse({ ok: false, reason: "apply_rules_failed", error: String(err?.message || err) });
        }
        break;
      }
      case "GET_STATUS": {
        const session = await getSession();
        sendResponse({ ok: true, session });
        break;
      }
      case "ADD_CURRENT_SITE": {
        const result = await addSiteToActiveSession(msg.domain);
        sendResponse(result);
        break;
      }
      case "SESSION_ENDED_EARLY": {
        // Sent from blocked.html once the unlock code is completed correctly.
        const session = await getSession();
        if (session) session.verified = false;
        await setSession(session);
        await endSession("manual_unlock");
        sendResponse({ ok: true });
        break;
      }
      case "EMERGENCY_UNLOCK_CONFIRMED": {
        // Sent after the website confirms the Rs.90 payment webhook-side
        // and hands back a short-lived token (validated in msg.payload).
        const session = await getSession();
        if (session) {
          session.verified = false;
          session.usedEmergencyUnlock = true;
          await setSession(session);
          await clearBlockRules();
          // Re-lock automatically after 30 minutes.
          await chrome.alarms.create("revm2-emergency-relock", {
            when: Date.now() + 30 * 60_000,
          });
        }
        sendResponse({ ok: true });
        break;
      }
      case "TOGGLE_ADULT_BLOCK": {
        await setAdultBlockEnabled(!!msg.enabled);
        sendResponse({ ok: true, enabled: !!msg.enabled });
        break;
      }
      case "GET_ADULT_BLOCK_STATE": {
        const settings = await getSettings();
        sendResponse({ ok: true, enabled: !!settings.blockAdultContent });
        break;
      }
      default:
        sendResponse({ ok: false, reason: "unknown_message" });
    }
  })();
  return true; // keep the message channel open for the async response
});
