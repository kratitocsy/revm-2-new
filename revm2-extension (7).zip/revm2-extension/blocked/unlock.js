// RevM2 - Unlock screen logic
// Runs inside blocked/blocked.html during an active focus session.
// Two paths: (1) type the 150-char code to end the session early,
// (2) pay Rs.90 for a 30-minute emergency unlock via the website backend.

const CODE_LENGTH = 150;
const CHARSET =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
// How many characters are visible in the scroll window at once. The person
// can drag the slider to look at any part of the 150-char code instead of
// it all being crammed into a wrapped, hard-to-read block.
const VISIBLE_CHARS = 32;

let currentCode = "";
let regenCount = 0;
let followTyping = true;
let resumeFollowTimer = null;
let mismatchTimeout = null;
let mismatchInterval = null;
let mismatchDeadline = null;

function generateCode(length = CODE_LENGTH) {
  const bytes = new Uint32Array(length);
  crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < length; i++) {
    out += CHARSET[bytes[i] % CHARSET.length];
  }
  return out;
}

function renderCode() {
  clearMismatchCountdown();
  currentCode = generateCode();
  const codeEl = document.getElementById("unlock-code");
  const sliderEl = document.getElementById("code-slider");
  const inputEl = document.getElementById("unlock-input");

  if (codeEl) {
    codeEl.innerHTML = "";
    const frag = document.createDocumentFragment();
    for (let i = 0; i < currentCode.length; i++) {
      const span = document.createElement("span");
      span.textContent = currentCode[i];
      span.className = "code-char";
      frag.appendChild(span);
    }
    codeEl.appendChild(frag);
  }
  if (sliderEl) {
    sliderEl.max = String(Math.max(0, CODE_LENGTH - VISIBLE_CHARS));
    sliderEl.value = "0";
  }
  followTyping = true;
  scrollCodeWindow(0);

  if (inputEl) {
    inputEl.value = "";
    inputEl.focus();
  }
  const unlockBtn = document.getElementById("unlock-btn");
  if (unlockBtn) unlockBtn.disabled = true;
  updateProgress(0);
}

function scrollCodeWindow(startIndex) {
  const codeEl = document.getElementById("unlock-code");
  if (codeEl) codeEl.style.transform = `translateX(-${startIndex}ch)`;
}

function updateProgress(typedLength) {
  const bar = document.getElementById("unlock-progress");
  if (bar) bar.style.width = `${(typedLength / CODE_LENGTH) * 100}%`;
}

function clearHighlight() {
  const codeEl = document.getElementById("unlock-code");
  if (!codeEl) return;
  const chars = codeEl.children;
  for (let i = 0; i < chars.length; i++) {
    chars[i].classList.remove("ok", "bad", "current");
  }
}

// Colors each character span green/red against what's been typed so far,
// and underlines the next character expected. Called live on every
// keystroke, plus again from attemptUnlock() when Unlock is clicked.
function highlightAgainst(typed) {
  const codeEl = document.getElementById("unlock-code");
  if (!codeEl) return;
  const chars = codeEl.children;
  for (let i = 0; i < chars.length; i++) {
    const span = chars[i];
    span.classList.remove("ok", "bad", "current");
    if (i < typed.length) {
      span.classList.add(typed[i] === currentCode[i] ? "ok" : "bad");
    } else if (i === typed.length) {
      span.classList.add("current");
    }
  }
}

function clearMismatchCountdown() {
  if (mismatchTimeout) clearTimeout(mismatchTimeout);
  if (mismatchInterval) clearInterval(mismatchInterval);
  mismatchTimeout = null;
  mismatchInterval = null;
  mismatchDeadline = null;
}

// After a failed attempt, give a full minute to fix it and retry with the
// SAME code before it gets regenerated - rather than yanking the code away
// almost immediately. The status line counts down live so it's clear how
// much time is left.
function startMismatchCountdown(firstBad) {
  clearMismatchCountdown();
  const statusEl = document.getElementById("unlock-status");
  const WINDOW_MS = 60000;
  mismatchDeadline = Date.now() + WINDOW_MS;

  const tick = () => {
    const remaining = Math.max(0, mismatchDeadline - Date.now());
    const secs = Math.ceil(remaining / 1000);
    if (statusEl) {
      statusEl.textContent = `Character ${firstBad + 1} didn't match. Fix it and hit Unlock again — ${secs}s left before the code resets.`;
    }
    if (remaining <= 0) {
      clearMismatchCountdown();
    }
  };
  tick();
  mismatchInterval = setInterval(tick, 250);
  mismatchTimeout = setTimeout(() => {
    clearMismatchCountdown();
    regenerate(`mismatch at character ${firstBad + 1}, timed out`);
  }, WINDOW_MS);
}

function regenerate(reason) {
  regenCount += 1;
  const statusEl = document.getElementById("unlock-status");
  if (statusEl) {
    statusEl.textContent = `Code reset (${reason}). Try again — attempt #${regenCount + 1}.`;
  }
  renderCode();
}

function initUnlockScreen() {
  renderCode();

  const inputEl = document.getElementById("unlock-input");
  if (!inputEl) return;

  // Block paste, drag-drop, and context-menu paste entirely.
  ["paste", "drop", "contextmenu"].forEach((evt) => {
    inputEl.addEventListener(evt, (e) => e.preventDefault());
  });

  // Any copy/cut attempt on the page (e.g. selecting the displayed code)
  // invalidates the current code immediately.
  ["copy", "cut"].forEach((evt) => {
    document.addEventListener(evt, (e) => {
      e.preventDefault();
      regenerate("copy attempt detected");
    });
  });

  // Losing focus on the tab/window (switching tabs, minimizing, alt-tabbing
  // to another app) resets progress. This also catches most OS-level
  // screenshot shortcuts (Win+Shift+S, Cmd+Shift+4) because they open a
  // full-screen overlay that pulls focus away from the browser first.
  // Note: this only sees browser-level focus changes. True cross-application
  // detection requires the desktop companion app (OS-level foreground
  // window hook) - not possible from a browser extension alone.
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      regenerate("left the tab");
    }
  });
  // NOTE: a window "blur" listener used to live here too, resetting the code
  // on ANY loss of window focus. That's far more trigger-happy than
  // visibilitychange - it also fires for in-page focus shifts that have
  // nothing to do with switching apps or tabs (browser spellcheck/autofill
  // popups, extension-injected UI stealing focus from the input, IME
  // candidate windows while typing special characters, etc). Removed it;
  // visibilitychange alone reliably catches real tab-switches, minimizing,
  // and most screenshot tools without the false positives.

  // Direct key capture for screenshot shortcuts that DON'T shift focus
  // (e.g. plain PrintScreen on Windows just copies to clipboard silently).
  // The browser still sees the keydown while it has focus, so we catch it
  // before the OS acts on it. Covers PrintScreen and the Mac region-capture
  // combos; doesn't cover third-party grab tools or an external camera -
  // no web API can see those, so this is a partial layer, not a guarantee.
  window.addEventListener("keydown", (e) => {
    const isPrintScreen = e.key === "PrintScreen";
    const isMacCapture =
      e.metaKey && e.shiftKey && ["3", "4", "5"].includes(e.key);
    if (isPrintScreen || isMacCapture) {
      regenerate("screenshot shortcut detected");
    }
  });

  // Live per-character feedback as they type, plus an Unlock button that
  // only checks/submits once the full code length is reached.
  const sliderEl = document.getElementById("code-slider");
  const unlockBtn = document.getElementById("unlock-btn");

  inputEl.addEventListener("input", () => {
    const typed = inputEl.value;

    // Live highlighting - colors update on every keystroke.
    highlightAgainst(typed);
    updateProgress(typed.length);

    if (unlockBtn) unlockBtn.disabled = typed.length !== CODE_LENGTH;

    // Keep the caret roughly centered in the visible window as they type,
    // so they don't have to manually scroll just to see what they're
    // typing against. Dragging the slider by hand (below) temporarily
    // pauses this so they can look ahead without it snapping back mid-drag.
    if (followTyping && sliderEl) {
      const maxStart = Number(sliderEl.max || 0);
      const start = Math.min(
        Math.max(0, typed.length - Math.floor(VISIBLE_CHARS / 2)),
        maxStart
      );
      sliderEl.value = String(start);
      scrollCodeWindow(start);
    }
  });

  if (unlockBtn) {
    unlockBtn.addEventListener("click", attemptUnlock);
  }

  if (sliderEl) {
    sliderEl.addEventListener("input", () => {
      followTyping = false;
      scrollCodeWindow(Number(sliderEl.value));
      // Resume auto-following the caret a couple seconds after the person
      // stops dragging, rather than forcing them to manually scroll back.
      clearTimeout(resumeFollowTimer);
      resumeFollowTimer = setTimeout(() => {
        followTyping = true;
      }, 2500);
    });
  }
}

// Only called once the person clicks Unlock - not on every keystroke - so
// correctness is never revealed mid-typing.
function attemptUnlock() {
  const inputEl = document.getElementById("unlock-input");
  const unlockBtn = document.getElementById("unlock-btn");
  if (!inputEl) return;

  const typed = inputEl.value;
  if (typed.length !== CODE_LENGTH) return;

  highlightAgainst(typed);
  if (unlockBtn) unlockBtn.disabled = true;

  if (typed === currentCode) {
    clearMismatchCountdown();
    confirmUnlock();
    return;
  }

  let firstBad = 0;
  while (firstBad < CODE_LENGTH && typed[firstBad] === currentCode[firstBad]) {
    firstBad++;
  }
  startMismatchCountdown(firstBad);
}

async function confirmUnlock() {
  const statusEl = document.getElementById("unlock-status");
  if (statusEl) statusEl.textContent = "Verifying...";

  // This hits the website backend, which is the source of truth for
  // session state - not just clearing local storage, or someone could
  // bypass via devtools. apiBase/token live under revm2Settings (see
  // utils/storage.js), not revm2Session - a previous version of this
  // read the wrong key, which meant every call here silently sent an
  // empty base URL and an empty auth header.
  try {
    const { revm2Settings } = await chrome.storage.local.get("revm2Settings");
    await fetch(`${revm2Settings?.apiBase ?? ""}/api/extension/session/end-early`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${revm2Settings?.token ?? ""}`,
      },
      body: JSON.stringify({ reason: "manual_unlock_code" }),
    });
  } catch (err) {
    console.warn("RevM2: end-early sync failed, ending session locally", err);
  }

  chrome.runtime.sendMessage({ type: "SESSION_ENDED_EARLY" });
  window.close();
}

async function startEmergencyUnlock() {
  const { revm2Settings } = await chrome.storage.local.get("revm2Settings");
  const webBase = revm2Settings?.webBase ?? "";
  const token = revm2Settings?.token ?? "";

  // Payment happens on the website (Razorpay checkout), not in the
  // extension - opens a new tab, backend confirms via webhook and
  // issues a short-lived unlock token the extension redeems below.
  chrome.tabs.create({
    url: `${webBase}/emergency-unlock?token=${encodeURIComponent(token)}`,
  });
}

// Reasons set by the various adult-content layers (rules/adult-blocklist.json,
// rules/adult-keyword-domains.json, content/rta-check.js, content/adult-
// heuristic.js) - each maps to a short, honest explanation of which layer
// caught the site.
const ADULT_REASON_COPY = {
  tld: "its domain ends in an adult-only TLD (.xxx / .porn / .adult / .sex).",
  keyword: "its domain matches a common adult-site naming pattern.",
  rta: 'it self-labels as "Restricted To Adults" (RTA).',
  content: "its page content matched several adult-content signals.",
};

function populateAdultContext(params, site, titleEl, subEl) {
  const reason = params.get("reason");
  if (titleEl) titleEl.textContent = "Adult content is blocked";
  if (subEl) {
    const reasonText = ADULT_REASON_COPY[reason] || "it matched your content filter.";
    subEl.textContent = site
      ? `${site} was blocked because ${reasonText}`
      : `This page was blocked because ${reasonText}`;
  }

  // This is a standing filter (Options -> Content filtering), not a focus
  // session - there's nothing here to "unlock early" with the 150-char
  // code, and it shouldn't be as easy to bypass as ending a focus block on
  // purpose. Replace that whole UI with a short explanation instead of
  // leaving a code-entry box that doesn't actually do anything useful here.
  const unlockBox = document.querySelector(".unlock-box");
  const emergencyBtn = document.getElementById("emergency-unlock-btn");
  const finePrint = document.querySelector(".fine-print");
  if (unlockBox) {
    unlockBox.innerHTML = `
      <p class="unlock-label">This isn't a timed focus session</p>
      <p style="font-size:12px;color:var(--muted);line-height:1.6;">
        Adult content filtering applies all the time, not just during a block.
        To turn it off, open the extension's Options page and switch off
        "Block adult content" - worth pausing on whether you actually want to.
      </p>
    `;
  }
  if (emergencyBtn) emergencyBtn.remove();
  if (finePrint) finePrint.remove();
}

function populateWhitelistContext(params, site, titleEl, subEl, session) {
  if (titleEl) {
    titleEl.textContent = session?.blockName
      ? `"${session.blockName}" only allows chosen sites`
      : "Only your allowed sites are reachable";
  }
  if (subEl) {
    subEl.textContent = site
      ? `${site} isn't on your allow list for this session, so it's blocked until the session ends.`
      : "This site isn't on your allow list for this session, so it's blocked until the session ends.";
  }
}

function populateYoutubeContext(site, titleEl, subEl, session) {
  const rules = session?.youtubeRules;
  if (titleEl) {
    titleEl.textContent = session?.blockName
      ? `"${session.blockName}" restricts YouTube channels`
      : "This YouTube channel is restricted";
  }
  if (subEl) {
    subEl.textContent =
      rules?.mode === "allow"
        ? "Only your chosen channels are reachable during this session."
        : "This channel is on your blocked-channels list for this session.";
  }
}

async function populateContext() {
  const params = new URLSearchParams(window.location.search);
  const site = params.get("site");
  const mode = params.get("mode");
  const isAdult = params.get("adult") === "1";
  const isYoutube = params.get("youtube") === "1";
  const { revm2Session } = await chrome.storage.local.get("revm2Session");

  const titleEl = document.getElementById("block-title");
  const subEl = document.getElementById("block-sub");

  if (isAdult) {
    populateAdultContext(params, site, titleEl, subEl);
  } else if (isYoutube) {
    populateYoutubeContext(site, titleEl, subEl, revm2Session);
  } else if (mode === "whitelist") {
    populateWhitelistContext(params, site, titleEl, subEl, revm2Session);
  } else {
    if (revm2Session?.blockName && titleEl) {
      titleEl.textContent = `"${revm2Session.blockName}" is active`;
    }
    if (site && subEl) {
      subEl.textContent = `${site} is blocked until your session ends.`;
    }
  }

  // Reached directly via the popup's "End block early" / "Emergency unlock"
  // shortcuts rather than a redirected site.
  if (params.get("emergency") === "1") {
    startEmergencyUnlock();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initUnlockScreen();
  populateContext();
});
document.getElementById("emergency-unlock-btn")?.addEventListener(
  "click",
  startEmergencyUnlock
);
