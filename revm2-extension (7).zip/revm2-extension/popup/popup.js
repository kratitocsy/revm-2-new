import { getPresets, savePreset, normalizeDomain } from "../utils/storage.js";

let selectedMinutes = 25;
let selectedMode = "blacklist"; // "blacklist" = block these sites, "whitelist" = allow only these sites

async function getCurrentTabDomain() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return null;
  try {
    return new URL(tab.url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

async function sendMessage(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

function formatTimeRemaining(session) {
  if (session.unlimited || !session.endsAt) return "Unlimited session";
  const msLeft = new Date(session.endsAt).getTime() - Date.now();
  if (msLeft <= 0) return "Ending...";
  const mins = Math.floor(msLeft / 60_000);
  const secs = Math.floor((msLeft % 60_000) / 1000);
  return `${mins}m ${secs.toString().padStart(2, "0")}s remaining`;
}

async function renderActiveView(session) {
  document.getElementById("start-view").classList.add("hidden");
  const view = document.getElementById("active-view");
  view.classList.remove("hidden");

  const mode = session.mode === "whitelist" ? "whitelist" : "blacklist";

  document.getElementById("active-block-name").textContent = session.blockName || "Focus block";
  document.getElementById("active-time-remaining").textContent = formatTimeRemaining(session);
  document.getElementById("active-sites-list").textContent = session.sites.join(" \u00b7 ");

  const badge = document.getElementById("active-mode-badge");
  if (badge) badge.textContent = mode === "whitelist" ? "Whitelist" : "Blacklist";
  const listLabel = document.getElementById("active-sites-list-label");
  if (listLabel) listLabel.textContent = mode === "whitelist" ? "Allowed sites" : "Blocked sites";

  const domain = await getCurrentTabDomain();
  const label = document.getElementById("current-site-label");
  const addBtn = document.getElementById("add-current-site-btn");

  const verb = mode === "whitelist" ? "Allow" : "Block";
  const verbPast = mode === "whitelist" ? "Allowed" : "Blocked";
  const alreadyLabel = mode === "whitelist" ? "Already allowed" : "Already blocked";

  if (!domain) {
    label.textContent = "no active tab";
    addBtn.disabled = true;
  } else if (session.sites.includes(domain)) {
    label.textContent = domain;
    addBtn.textContent = alreadyLabel;
    addBtn.disabled = true;
  } else {
    label.textContent = domain;
    addBtn.textContent = `${verb} this site now`;
    addBtn.disabled = false;
    addBtn.onclick = async () => {
      addBtn.textContent = `${verb}ing...`;
      const result = await sendMessage("ADD_CURRENT_SITE", { domain });
      if (result.ok) {
        addBtn.textContent = verbPast;
        addBtn.disabled = true;
        renderActiveView(result.session || (await sendMessage("GET_STATUS")).session);
      }
    };
  }
}

function renderStartView() {
  document.getElementById("active-view").classList.add("hidden");
  document.getElementById("start-view").classList.remove("hidden");
}

async function loadPresets() {
  const presets = await getPresets();
  const row = document.getElementById("presets-row");
  row.innerHTML = "";
  Object.values(presets).forEach((preset) => {
    const chip = document.createElement("button");
    chip.className = "preset-chip";
    chip.textContent = preset.name;
    chip.onclick = () => {
      document.getElementById("block-name").value = preset.name;
      document.getElementById("sites-input").value = preset.sites.join("\n");
      setMode(preset.mode === "whitelist" ? "whitelist" : "blacklist");
    };
    row.appendChild(chip);
  });
}

function wireDurationChips() {
  const chips = document.querySelectorAll(".duration-chip");
  chips.forEach((chip) => {
    chip.onclick = () => {
      chips.forEach((c) => c.classList.remove("selected"));
      chip.classList.add("selected");
      selectedMinutes = Number(chip.dataset.minutes);
    };
  });
  chips[0].classList.add("selected");
}

function setMode(mode) {
  selectedMode = mode === "whitelist" ? "whitelist" : "blacklist";
  document.querySelectorAll(".mode-chip").forEach((chip) => {
    chip.classList.toggle("selected", chip.dataset.mode === selectedMode);
  });

  const label = document.getElementById("sites-input-label");
  const hint = document.getElementById("sites-input-hint");
  const textarea = document.getElementById("sites-input");
  if (selectedMode === "whitelist") {
    if (label) label.textContent = "Sites to allow";
    if (hint) hint.textContent = "One per line. Everything else gets blocked.";
    if (textarea) textarea.placeholder = "notion.so\ngmail.com\nyourcompany.slack.com";
  } else {
    if (label) label.textContent = "Sites to block";
    if (hint) hint.textContent = "One per line. Everything else stays reachable.";
    if (textarea) textarea.placeholder = "youtube.com\ninstagram.com\nreddit.com";
  }
}

function wireModeChips() {
  document.querySelectorAll(".mode-chip").forEach((chip) => {
    chip.onclick = () => setMode(chip.dataset.mode);
  });
}

async function handleStartBlock() {
  const blockName = document.getElementById("block-name").value.trim() || "Focus block";
  const rawSites = document.getElementById("sites-input").value
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean)
    .map(normalizeDomain);

  if (rawSites.length === 0) {
    alert(selectedMode === "whitelist" ? "Add at least one site to allow." : "Add at least one site to block.");
    return;
  }

  // Offer to save as a reusable preset for next time.
  savePreset({
    id: blockName.toLowerCase().replace(/\s+/g, "-"),
    name: blockName,
    sites: rawSites,
    mode: selectedMode,
  });

  const result = await sendMessage("START_SESSION", {
    payload: {
      blockName,
      sites: rawSites,
      durationMinutes: selectedMinutes === 0 ? null : selectedMinutes,
      mode: selectedMode,
    },
  });

  if (result.ok) {
    renderActiveView(result.session);
  } else {
    // Don't fail silently - a block that looks started but isn't actually
    // enforced is worse than an obvious error the person can retry.
    alert(
      "Couldn't start this block: " +
        (result.error || result.reason || "unknown error") +
        "\n\nNothing is being blocked yet. Please try again."
    );
  }
}

async function init() {
  const status = await sendMessage("GET_STATUS");
  if (status.ok && status.session?.active) {
    await renderActiveView(status.session);
  } else {
    renderStartView();
    await loadPresets();
    wireDurationChips();
    wireModeChips();
    setMode("blacklist");
  }

  document.getElementById("start-block-btn")?.addEventListener("click", handleStartBlock);
  document.getElementById("end-early-btn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("blocked/blocked.html?manual=1") });
  });
  document.getElementById("emergency-unlock-btn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("blocked/blocked.html?manual=1&emergency=1") });
  });
  document.getElementById("open-options-link")?.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  // Keep the countdown fresh while the popup is open.
  setInterval(async () => {
    const s = await sendMessage("GET_STATUS");
    if (s.ok && s.session?.active) {
      const el = document.getElementById("active-time-remaining");
      if (el) el.textContent = formatTimeRemaining(s.session);
    }
  }, 1000);
}

document.addEventListener("DOMContentLoaded", init);
